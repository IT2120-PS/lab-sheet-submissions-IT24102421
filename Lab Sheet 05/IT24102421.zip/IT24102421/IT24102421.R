setwd("C:\\Users\\Admin\\Desktop\\IT24102421")

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

fix(Delivery_Times)
attach(Delivery_Times)

histogram <- hist(Delivery_Times$Delivery_Time_.minutes., 
                  main = "Histogram of Delivery Times",
                  xlab = "Delivery Time (minutes)",
                  breaks = seq(20, 70, length = 10),
                  right = FALSE)


# 4. Draw cumulative frequency polygon in a separate plot
breaks <- round(histogram$breaks)
freq <- histogram$counts
cum_freq <- cumsum(freq)

# Create cumulative frequency data for polygon
p_data <- c(0, cum_freq)

# Plot the polygon
plot(breaks, p_data, 
     type = "l", 
     main = "Cumulative Frequency Polygon of Delivery Times",
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency",
     col = "blue",
     lwd = 2)

points(breaks, ogive_data, col = "red", pch = 16)

